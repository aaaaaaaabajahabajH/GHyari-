const stats = [{label:"إجمالي المنتجات",value:"—",note:"اربط قاعدة البيانات لعرض بياناتك"},{label:"طلبات اليوم",value:"—",note:"ستظهر الطلبات هنا"},{label:"قيمة المخزون",value:"—",note:"تُحسب من منتجات متجرك"},{label:"عملاء نشطون",value:"—",note:"إحصائيات العملاء"}];
const features = [
  ["◈","إدارة المخزون","تابع القطع والكميات والتنبيهات عند انخفاض المخزون."],
  ["▤","الطلبات وعروض الأسعار","جهّز عروض أسعار منظمة وتابع حالة كل طلب."],
  ["✦","مساعد غياري AI","اكتب أوصاف المنتجات والإعلانات ورسائل العملاء بسرعة."],
  ["◎","ملفات العملاء","احتفظ ببيانات العملاء وسجل تعاملاتهم في مكان واحد."],
  ["⌁","تقارير المتجر","افهم حركة المبيعات والمخزون من لوحة واحدة."],
  ["↗","نمو الاشتراكات","خطط اشتراك واضحة للمحلات مع قابلية التوسع."]
];
export default function Home() {
 return <main className="shell">
  <header className="top"><div className="brand"><div className="mark">G</div><div>GHAYARI <span style={{color:"var(--gold)"}}>AI</span><div style={{fontSize:11,color:"var(--muted)",fontWeight:400}}>BUSINESS PLATFORM</div></div></div><div className="pill">نسخة تأسيسية · الإمارات</div></header>
  <section className="hero"><div className="eyebrow">منصة ذكية لقطاع قطع غيار السيارات</div><h1>إدارة متجرك تبدأ بقرار أذكى.</h1><p>منصة غياري تجمع إدارة المخزون والعملاء والطلبات ومساعد الذكاء الاصطناعي في مساحة عمل واحدة، مصممة لتناسب محلات قطع غيار السيارات في الإمارات.</p><div className="actions"><a className="btn" href="#features" style={{textDecoration:"none"}}>اكتشف المنصة</a><a className="btn secondary" href="mailto:hello@ghayari.ai" style={{textDecoration:"none"}}>تواصل معنا</a></div></section>
  <section><h2 className="section-title">نظرة عامة على المتجر</h2><div className="grid">{stats.map(s=><div className="stat" key={s.label}><small>{s.label}</small><strong>{s.value}</strong><small>{s.note}</small></div>)}</div></section>
  <section id="features"><h2 className="section-title">كل أدوات عملك في مكان واحد</h2><div className="features">{features.map(f=><article className="feature" key={f[1]}><div className="ico">{f[0]}</div><h3>{f[1]}</h3><p>{f[2]}</p></article>)}</div></section>
  <footer className="bottom">© {new Date().getFullYear()} GHAYARI AI BUSINESS · صُممت لخدمة متاجر قطع غيار السيارات في الإمارات.</footer>
 </main>;
}
