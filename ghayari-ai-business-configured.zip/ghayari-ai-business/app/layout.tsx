import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "غياري AI | إدارة ذكية لقطع غيار السيارات",
  description: "منصة ذكية لإدارة محلات قطع غيار السيارات والمخزون والعملاء في الإمارات."
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="ar" dir="rtl"><body>{children}</body></html>;
}
