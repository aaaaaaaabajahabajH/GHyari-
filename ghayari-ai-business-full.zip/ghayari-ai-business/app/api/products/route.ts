import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
export async function POST(req:Request){
  const form=await req.formData();
  const name=String(form.get("name")||"").trim(), sku=String(form.get("sku")||"").trim();
  const price=Number(form.get("price")), quantity=Number(form.get("quantity")||0);
  if(!name||!Number.isFinite(price)||price<0||!Number.isInteger(quantity)||quantity<0) return NextResponse.json({error:"تحقق من بيانات المنتج."},{status:400});
  try{
    const supabase=createClient(); const {data:{user}}=await supabase.auth.getUser();
    if(!user) return NextResponse.json({error:"سجّل الدخول أولاً."},{status:401});
    const {error}=await supabase.from("products").insert({owner_id:user.id,name,sku:sku||null,price,quantity});
    if(error) throw error;
    return NextResponse.redirect(new URL("/",req.url),303);
  }catch{return NextResponse.json({error:"تعذر حفظ المنتج. تأكد من تشغيل مخطط قاعدة البيانات."},{status:500});}
}
