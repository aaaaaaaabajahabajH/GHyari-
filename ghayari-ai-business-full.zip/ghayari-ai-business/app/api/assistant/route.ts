import OpenAI from "openai";
import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
export async function POST(req: Request) {
  const form = await req.formData();
  const prompt = String(form.get("prompt") || "").trim();
  if (!prompt) return NextResponse.json({error:"اكتب طلبك أولاً."},{status:400});
  if (!process.env.OPENAI_API_KEY) return NextResponse.json({error:"مساعد AI غير مفعّل بعد. أضف OPENAI_API_KEY في إعدادات الاستضافة."},{status:503});
  try {
    const supabase = createClient();
    const {data:{user}} = await supabase.auth.getUser();
    if (!user) return NextResponse.json({error:"سجّل الدخول أولاً."},{status:401});
    const ai = new OpenAI({apiKey:process.env.OPENAI_API_KEY});
    const completion = await ai.chat.completions.create({
      model:process.env.OPENAI_MODEL || "gpt-4o-mini",
      messages:[
        {role:"system",content:"أنت مساعد تسويق ومبيعات متخصص لمحلات قطع غيار السيارات في الإمارات. أجب بالعربية الخليجية الواضحة. لا تخترع التوافق أو التوفر أو الأسعار أو أرقام القطع. نبّه دائماً إلى التحقق من رقم القطعة ورقم الهيكل ومواصفات السيارة قبل تأكيد التوافق."},
        {role:"user",content:prompt}
      ],temperature:0.6
    });
    const answer=completion.choices[0]?.message?.content || "لم أتمكن من إنشاء الرد.";
    return NextResponse.json({answer});
  } catch { return NextResponse.json({error:"حدث خطأ أثناء الاتصال بمساعد AI."},{status:500}); }
}
