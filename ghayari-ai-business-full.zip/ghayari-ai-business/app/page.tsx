import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
export default async function Home() {
  let products: any[] = [], orders: any[] = [], configured = true, user: any = null;
  try {
    const supabase = createClient();
    const auth = await supabase.auth.getUser(); user = auth.data.user;
    if (user) {
      const p = await supabase.from("products").select("*").order("created_at",{ascending:false}).limit(5);
      const o = await supabase.from("orders").select("*").order("created_at",{ascending:false}).limit(5);
      products=p.data||[]; orders=o.data||[];
    }
  } catch { configured = false; }
  return <div className="shell">
    <aside className="side"><div className="brand">GHAYARI <b>AI</b><small>BUSINESS SUITE</small></div><div className="store">متجر قطع الغيار الخاص بك<br/><span className="muted">مساحة إدارة المتجر</span></div>
      <nav className="nav"><a className="active" href="/">نظرة عامة</a><a href="#assistant">مساعد AI</a><a href="#products">المنتجات</a><a href="#orders">الطلبات</a><a href="/billing">الاشتراكات</a><a href="/login">الحساب</a></nav>
      <div className="side-foot">GHAYARI AI BUSINESS<br/>منصة لإدارة محلات قطع غيار السيارات</div>
    </aside>
    <main className="main"><header className="top"><b>لوحة التحكم</b><span>{user?.email || "وضع المعاينة"} · <Link href="/login">تسجيل الدخول</Link></span></header>
      <section className="content"><div className="welcome"><div><span className="badge">إدارة ذكية لقطع الغيار</span><h1>أهلاً بك في غياري AI</h1><p>تابع متجرك، جهّز محتوى المنتجات، ونظّم طلبات العملاء من مكان واحد.</p></div><Link className="btn dark" href="/login">دخول / إنشاء حساب</Link></div>
      {!configured && <div className="notice">لم يتم إعداد Supabase بعد. أضف مفاتيح البيئة وشغّل ملف قاعدة البيانات SQL لتفعيل الحسابات والبيانات.</div>}
      <div className="stats"><div className="card"><label>المنتجات المسجلة</label><strong>{products.length}</strong><small>منتجات في قاعدة بياناتك</small></div><div className="card"><label>الطلبات المسجلة</label><strong>{orders.length}</strong><small>طلبات حديثة</small></div><div className="card"><label>مساعد الذكاء الاصطناعي</label><strong>AI</strong><small>يتطلب مفتاح API</small></div><div className="card"><label>الاشتراك</label><strong>تجريبي</strong><small>الدفع يحتاج إعداد بوابة</small></div></div>
      <div className="grid"><section className="panel" id="assistant"><h2>مساعد غياري AI</h2><div className="sub">أنشئ إعلاناً أو وصفاً أو رسالة متابعة للعميل.</div><form action="/api/assistant" method="post" className="ai-box"><textarea name="prompt" placeholder="مثال: اكتب إعلاناً احترافياً لبطارية سيارة..."></textarea><div className="row" style={{marginTop:10}}><button className="btn" type="submit">إنشاء محتوى</button><span className="muted">يعمل بعد إضافة OPENAI_API_KEY</span></div></form></section>
      <section className="panel" id="products"><h2>إضافة منتج</h2><p className="sub">سجّل منتجاً في مخزون متجرك.</p><form action="/api/products" method="post"><label className="field">اسم القطعة<input name="name" required placeholder="مثال: فلتر زيت"/></label><label className="field">رقم القطعة<input name="sku" placeholder="اختياري"/></label><label className="field">السعر بالدرهم<input name="price" type="number" min="0" step="0.01" required/></label><label className="field">الكمية<input name="quantity" type="number" min="0" defaultValue="1"/></label><button className="btn" type="submit">حفظ المنتج</button></form></section></div>
      <section className="panel" id="orders" style={{marginTop:15}}><h2>أحدث المنتجات</h2><div className="sub">يتم عرض المنتجات المحفوظة في حسابك بعد تفعيل قاعدة البيانات.</div><table className="table"><thead><tr><th>المنتج</th><th>رقم القطعة</th><th>السعر</th><th>الكمية</th></tr></thead><tbody>{products.map(p=><tr key={p.id}><td>{p.name}</td><td>{p.sku||"—"}</td><td>{p.price} د.إ</td><td>{p.quantity}</td></tr>)}{products.length===0&&<tr><td colSpan={4}>لا توجد منتجات بعد.</td></tr>}</tbody></table></section>
      <p className="muted" style={{marginTop:20}}>نسخة تأسيسية: الأرقام التجريبية غير مستخدمة؛ تظهر بيانات حسابك بعد الإعداد.</p>
      </section></main></div>;
}
