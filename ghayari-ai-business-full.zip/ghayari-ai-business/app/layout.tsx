import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "GHAYARI AI BUSINESS",
  description: "منصة ذكية لإدارة محلات قطع غيار السيارات",
  applicationName: "GHAYARI AI BUSINESS"
};
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="ar" dir="rtl"><body>{children}</body></html>;
}
