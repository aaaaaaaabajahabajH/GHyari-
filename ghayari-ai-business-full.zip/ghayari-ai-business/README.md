# GHAYARI AI BUSINESS — Full-stack starter

A mobile-friendly Arabic RTL Next.js starter for UAE automotive spare-parts shops.

## Included
- Next.js App Router dashboard, Arabic RTL responsive layout.
- Supabase email/password authentication page.
- Supabase schema for profiles, products, customers, orders, quotes and subscriptions with Row Level Security.
- Product creation API requiring an authenticated user.
- Server-side OpenAI assistant endpoint (API key stays on server).
- Subscription pricing page and environment placeholders for Stripe.
- Environment example and deployment notes.

## Important status
This is an integration-ready starter, not a live commercial service yet:
- Supabase, OpenAI and Stripe credentials have not been supplied or connected.
- Billing page intentionally does not accept payments yet.
- WhatsApp variables are placeholders; no WhatsApp messages are sent.
- Order/customer management UI and supplier marketplace workflows still need additional screens and tests.
- No real inventory, fitment, prices or supplier data is included.
- AI text is assistance only; verify part number, VIN and vehicle specifications before confirming fitment.

## Setup
1. Create a Supabase project.
2. In Supabase SQL Editor, run `supabase/schema.sql`.
3. Copy `.env.example` to `.env.local`, then fill `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY`.
4. Add `OPENAI_API_KEY` to enable the AI endpoint.
5. Install dependencies with `npm install`, then run `npm run dev`.
6. Deploy to Vercel and add the same environment variables in Project Settings.

## iPhone workflow
Use Safari to open GitHub Codespaces or the Vercel dashboard. Upload/push this project to a GitHub repository, open it in Codespaces, and run the commands above in the terminal. You can also import the repository into Vercel for deployment.

## Production checklist
- Configure Supabase email templates, redirect URLs, backups and RLS review.
- Add server-side authorization and rate limits to all business actions.
- Implement complete customer/order/quote CRUD and audit logging.
- Create Stripe products/prices, checkout and verified webhook handling before accepting payments.
- Add WhatsApp Cloud API webhook verification, approved templates and opt-in handling.
- Add privacy policy, terms, support contacts, tax/accounting review and UAE business compliance.
- Test on real devices and run a security review before launch.
