-- GHAYARI AI BUSINESS initial schema
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  business_name text,
  full_name text,
  phone text,
  role text not null default 'owner' check (role in ('owner','staff')),
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  sku text,
  make text,
  model text,
  year_from int,
  year_to int,
  price numeric(12,2) not null default 0 check(price >= 0),
  quantity int not null default 0 check(quantity >= 0),
  description text,
  created_at timestamptz not null default now()
);

create table if not exists public.customers (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  phone text,
  email text,
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  customer_id uuid references public.customers(id) on delete set null,
  order_number text,
  status text not null default 'new' check(status in ('new','quoted','confirmed','completed','cancelled')),
  total numeric(12,2) not null default 0,
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  description text not null,
  quantity int not null default 1 check(quantity > 0),
  unit_price numeric(12,2) not null default 0 check(unit_price >= 0)
);

create table if not exists public.quotes (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  order_id uuid references public.orders(id) on delete set null,
  customer_name text not null,
  description text not null,
  amount numeric(12,2) not null default 0,
  status text not null default 'draft' check(status in ('draft','sent','accepted','rejected')),
  valid_until date,
  created_at timestamptz not null default now()
);

create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null unique references auth.users(id) on delete cascade,
  provider text not null default 'stripe',
  provider_customer_id text,
  provider_subscription_id text,
  plan text not null default 'trial',
  status text not null default 'inactive',
  current_period_end timestamptz,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.customers enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.quotes enable row level security;
alter table public.subscriptions enable row level security;

create policy "profile own select" on public.profiles for select using (auth.uid() = id);
create policy "profile own insert" on public.profiles for insert with check (auth.uid() = id);
create policy "profile own update" on public.profiles for update using (auth.uid() = id);
create policy "products own all" on public.products for all using (auth.uid() = owner_id) with check (auth.uid() = owner_id);
create policy "customers own all" on public.customers for all using (auth.uid() = owner_id) with check (auth.uid() = owner_id);
create policy "orders own all" on public.orders for all using (auth.uid() = owner_id) with check (auth.uid() = owner_id);
create policy "quotes own all" on public.quotes for all using (auth.uid() = owner_id) with check (auth.uid() = owner_id);
create policy "subscriptions own select" on public.subscriptions for select using (auth.uid() = owner_id);
create policy "order items own via order" on public.order_items for all
using (exists(select 1 from public.orders o where o.id = order_id and o.owner_id = auth.uid()))
with check (exists(select 1 from public.orders o where o.id = order_id and o.owner_id = auth.uid()));

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles(id, full_name) values(new.id, coalesce(new.raw_user_meta_data->>'full_name',''));
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();
